package com.nelson.sign.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class clazz {

    @Id
    @GeneratedValue
    @Column(name = "clazz_id")
    private Long clszzId;

    private String name;

    @Column(name = "pclazz_id")
    private Long pclazzId;

}
