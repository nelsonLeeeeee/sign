package com.nelson.sign.Repository;

public interface clazzRepository {
}
