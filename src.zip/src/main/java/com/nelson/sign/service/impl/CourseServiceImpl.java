package com.nelson.sign.service.impl;

import com.nelson.sign.Repository.CourseRepository;
import com.nelson.sign.Repository.CourseTimeRepository;
import com.nelson.sign.entity.Course;
import com.nelson.sign.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private CourseTimeRepository courseTimeRepository;

    @Override
    public Course getCourseByCourseId(Long courseId) {
        Course course = this.courseRepository.getCourseByCourseId(courseId);
        if(course==null){
            return  null;
        }
        return course;
    }

    @Override
    public Course addCourse(Course course) {
        return this.courseRepository.saveAndFlush(course);
    }

    @Override
    public List<Course> getStudentCourse(Long studenId, Long startTime, Long endTime) {
        //这里应该是clazzId              注意了注意了 记得改
        String clazzId = "";
        return this.courseTimeRepository.getCourseByClazzIdAndStartTimeBeforeAndEndTimeAfter(clazzId,startTime, endTime);
    }
}
