package com.nelson.sign.service.impl;

import com.nelson.sign.service.TeacherService;
import org.springframework.stereotype.Service;

@Service
public class TeacherServiceImpl implements TeacherService {
}
