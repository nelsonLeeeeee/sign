package com.nelson.sign.service;

public interface LeaveService {
}
