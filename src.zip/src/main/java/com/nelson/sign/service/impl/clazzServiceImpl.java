package com.nelson.sign.service.impl;

import com.nelson.sign.service.clazzService;
import org.springframework.stereotype.Service;

@Service
public class clazzServiceImpl implements clazzService {
}
