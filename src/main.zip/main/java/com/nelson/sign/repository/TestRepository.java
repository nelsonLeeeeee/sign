package com.nelson.sign.repository;


import com.nelson.sign.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TestRepository extends JpaRepository<User, Long> {

//    @Query(value = "select uid,name,passWord,lastLoginTime,isUsed from User where name = ?1 and passWord = ?2")
    public User getUserByNameAndPassWord(String name,String passWord);

    public User findUserByuid(long uid);
}
