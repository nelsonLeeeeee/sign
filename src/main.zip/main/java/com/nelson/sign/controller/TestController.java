package com.nelson.sign.controller;

import com.nelson.sign.entity.User;
import com.nelson.sign.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
public class TestController {

    @Autowired
    private TestService testService;

    @GetMapping("/getUser")
    public User getUser() {
        User user=new User();
        user.setName("nelson");
        user.setPassWord("123456");
        user =  this.testService.getUser(user.getName(),user.getPassWord());
        return user;
    }

    @GetMapping("/findUser")
    public User findUser() {
        User user=new User();
        user.setName("nelson");
        user.setPassWord("123456");
        user =  this.testService.findUserByUid(1L);
        return user;
    }

}
