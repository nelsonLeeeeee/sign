package com.nelson.sign.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "user")
public class User implements Serializable {
    @Id
    @GeneratedValue
    private Long uid;

    private String name;
    @Column(name = "password")
    private String passWord;
    @Column(name = "last_login_time")
    private Long lastLoginTime;
    @Column(name = "isused")
    private int isUsed;

    public User() {
    }

    public User(String name, String passWord, Long lastLoginTime, int isUsed) {
        this.name = name;
        this.passWord = passWord;
        this.lastLoginTime = lastLoginTime;
        this.isUsed = isUsed;
    }

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public Long getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(Long lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public int getIsUsed() {
        return isUsed;
    }

    public void setIsUsed(int isUsed) {
        this.isUsed = isUsed;
    }
}
