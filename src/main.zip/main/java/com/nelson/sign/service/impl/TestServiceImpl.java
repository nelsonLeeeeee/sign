package com.nelson.sign.service.impl;

import com.nelson.sign.entity.User;
import com.nelson.sign.repository.TestRepository;
import com.nelson.sign.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class TestServiceImpl implements TestService {

    @Autowired
    private TestRepository testRepository;

    @Override
    @Transactional
    public User getUser(String name, String passWord) {
        return this.testRepository.getUserByNameAndPassWord(name,passWord);
    }

    @Override
    public User findUserByUid(long uid) {
        return this.testRepository.findUserByuid(uid);
    }
}
