package com.nelson.sign.service;

import com.nelson.sign.entity.User;

public interface TestService {
    User getUser(String name,String passWord);

    User findUserByUid(long l);
}
